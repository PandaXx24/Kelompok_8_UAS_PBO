import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The text class is used only for the purpose of displaying text to the user.
 * @version Desember 7, 2023
 */
public class Text extends Actor
{
    /**
     * A constructor for the Text class
     * @param text the text to be displayed
     */
    public Text(String text){
        setImage(new GreenfootImage(text, 36, Color.BLACK,null));//display the text
    }
    
    /**
     * Another constructor for the Text class
     * @param text the text to be displayed
     * @param size the font size to be used
     */
    public Text(String text, int size){
        setImage(new GreenfootImage(text, size, Color.BLACK,null));//display the text
    }
}
